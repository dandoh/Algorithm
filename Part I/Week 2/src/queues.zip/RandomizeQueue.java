import java.util.Iterator;
import java.util.NoSuchElementException;

public class RandomizeQueue<Item> implements Iterable<Item> {
	
	private Item s[];
	private int N;
	
	public RandomizeQueue() {
		s = (Item[]) new Object[2];
		N = 0;
	}
	public boolean isEmpty() { return N == 0; }
	public int size() { return N; }
	public void enque(Item item) {
		if (item == null) 
			throw new NullPointerException();
		if (N == s.length) {
			Item copy[] = (Item[]) new Object[2 * N];
			for (int i = 0; i < N; i++){
				copy[i] = s[i];
			}
			s = copy;
		}
		s[N] = item;
		int r = StdRandom.uniform(N + 1);
		//swap 
		Item tmp = s[r];
		s[r] = s[N];
		s[N] = tmp;
		
		N++;
	}
	public Item deque() {
		if (isEmpty())
			throw new NoSuchElementException();
		Item item = s[N - 1];
		N--;
		if (N > 0 && N < s.length / 4) {
			Item copy[] = (Item[]) new Object[s.length / 2];
			for (int i = 0; i < N; i++) {
				copy[i] = s[i];
			}
			s = copy;
		}
		
		return item;
	}
	
	public Item sample() {
		return s[N - 1];
	}
		
	//ITERATOR and NODE
	@Override
	public Iterator<Item> iterator() {
		return new RandomizeQueueIterator(s, N);
	}

	private class RandomizeQueueIterator implements Iterator<Item> {
		Item[] item;
		int current;
		int size;
		public RandomizeQueueIterator(Item[] item, int N) {
			this.item = item;
			current = 0;
			size = N;
			StdRandom.shuffle(item, 0, size - 1);
		}
		
		@Override
		public boolean hasNext() {
			return current < size;
		}

		@Override
		public Item next() {
			if (!hasNext())
				throw new NoSuchElementException();
			return item[current];
		}

		@Override
		public void remove() {
			/* Not supported */
			throw new UnsupportedOperationException();
		}

	}
	
}
